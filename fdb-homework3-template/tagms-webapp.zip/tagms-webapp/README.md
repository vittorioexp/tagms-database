# README #

### What is this repository for? ###

* A really simple webapp to test the principal queries using jdbc for the project Tagms
* Version 1.0

# How do I run tests? #

* run the file src > java > main > ... > Tagms.java